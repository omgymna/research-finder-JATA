# research-finder
Team 19: JATA Development

Project Overview:

Match students interested in research with faculty/ projects. Both enter in various info including
classes taken, types of projects interested in. Faculty enter project summaries and keywords,
how many students, and types of skills needed. System recommends matches and lets the
students know to contact the faculty as well letting the faculty know who the students are to
expect. The system can also note who is working on what project to keep track of collaborators.